======================
Internal API Reference
======================

.. toctree::
   :maxdepth: 1

   autoindex
